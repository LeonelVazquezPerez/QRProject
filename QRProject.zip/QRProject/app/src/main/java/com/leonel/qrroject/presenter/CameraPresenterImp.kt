package com.leonel.qrroject.presenter

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.leonel.qrroject.view.CameraFragmentView

class CameraPresenterImp(var vista:CameraFragmentView,var context: Context):CameraPresenter {

    override fun checkPermissions() {
        //if system os is Marshmallow or Above, we need to request runtime permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
                == PackageManager.PERMISSION_DENIED
            ) {

                //show popup to request permission
                vista.getPermissions()
                //
            } else {
                //permission already granted
                //openCamera()
                vista.openCamera()
            }
        } else {
            //system os is < marshmallow
            //openCamera()
            vista.openCamera()
        }
    }

}