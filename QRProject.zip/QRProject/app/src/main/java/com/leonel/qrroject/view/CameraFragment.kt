package com.leonel.qrroject.view

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import com.google.firebase.ml.vision.FirebaseVision
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcode
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcodeDetectorOptions
import com.google.firebase.ml.vision.common.FirebaseVisionImage
import com.leonel.qrroject.R
import com.leonel.qrroject.model.Qr
import com.leonel.qrroject.presenter.CameraPresenterImp
import com.leonel.qrroject.presenter.FirestoreServiceImp
import kotlinx.android.synthetic.main.fragment_camera.*
import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.util.*

class CameraFragment : Fragment(),CameraFragmentView {

    lateinit var vista:View
    lateinit var useremail:String
    lateinit var userlatitude:String
    lateinit var userlongitude:String
    val PERMISSION_CODE = 1000
    var image_uri: Uri? = null
    var REQUEST_IMAGE_CAPTURE = 1
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        useremail = arguments?.getString("user").toString()
        userlatitude = arguments?.getString("lat").toString()
        userlongitude = arguments?.getString("lon").toString()
        Log.d("Mensaje","Fragment ubicacion: $userlatitude , $userlongitude")
        // Inflate the layout for this fragment
        vista = inflater.inflate(R.layout.fragment_camera, container, false)

        return vista
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val cameraPresenter = CameraPresenterImp(this,vista.context)
        buttonScan.setOnClickListener {
            cameraPresenter.checkPermissions()
        }
    }

    override fun getPermissions() {
               //permission was not enabled
               val permission = arrayOf(
                   Manifest.permission.CAMERA,
                   Manifest.permission.WRITE_EXTERNAL_STORAGE
               )
               requestPermissions(permission, PERMISSION_CODE)

    }

    override fun openCamera() {
        val values = ContentValues()
        values.put(MediaStore.Images.Media.TITLE, "New Scan")
        values.put(MediaStore.Images.Media.DESCRIPTION, "From the Camera")
        image_uri = vista.context.contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        )


        //camera intent
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(vista.context.packageManager)?.also {
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        //called when user presses ALLOW or DENY from Permission Request Popup
        when (requestCode) {
            PERMISSION_CODE -> {
                if (grantResults.size > 0 && grantResults[0] ==
                    PackageManager.PERMISSION_GRANTED
                ) {
                    //permission from popup was granted
                    openCamera()
                } else {
                    //permission from popup was denied
                    Toast.makeText(vista.context, "Permiso Denegado", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        //called when image was captured from camera intent
        if (resultCode == Activity.RESULT_OK) {
            if (data != null) {
                val imageBitmap = data.extras!!.get("data") as Bitmap
                photoimageView.setImageBitmap(imageBitmap)
                //Configurar el detector de codigos de barras solo para QR
                val options = FirebaseVisionBarcodeDetectorOptions.Builder()
                    .setBarcodeFormats(
                        FirebaseVisionBarcode.FORMAT_QR_CODE)
                    .build()
                val image = FirebaseVisionImage.fromBitmap(imageBitmap)
                val detector = FirebaseVision.getInstance()
                    .getVisionBarcodeDetector(options)

                val result = detector.detectInImage(image)
                    .addOnSuccessListener { barcodes ->
                        Log.d("CameraXApp","OnSucces $barcodes")
                        for (barcode in barcodes) {
                            val location = barcode.geoPoint
                            Log.d("Mensaje","location : ${location?.lat} / ${location?.lng}")
                            val rawValue = barcode.rawValue
                            Log.d("CameraXApp","Valor analizado: $rawValue")
                            tvResultado.text = rawValue
                            val valueType = barcode.valueType
                            // See API reference for complete list of supported types
                            when (valueType) {
                                FirebaseVisionBarcode.TYPE_WIFI -> {
                                    val ssid = barcode.wifi!!.ssid
                                    val password = barcode.wifi!!.password
                                    val type = barcode.wifi!!.encryptionType
                                }
                                FirebaseVisionBarcode.TYPE_URL -> {
                                    val title = barcode.url!!.title
                                    val url = barcode.url!!.url
                                }
                            }

                            val now = Date()
                            val timestamp: Long = now.getTime()
                            val sdf = SimpleDateFormat("MM/dd/yyyy HH:mm:ss", Locale.US)
                            val dateStr: String = sdf.format(timestamp)
                            var qr = Qr(useremail,userlatitude,userlongitude,rawValue.toString(),
                                dateStr)
                            //DateTimeFormatter.ISO_INSTANT.format(Instant.now())
                            var firestore = FirestoreServiceImp()
                            firestore.insertQR(qr)

                        }
                    }
                    .addOnFailureListener {
                        Log.d("CameraXApp","ocurrio un error al analizar la imagen")
                        tvResultado.text = "Sin resultados"
                    }
            } else {

            }
            //Toast.makeText(vista.context, "DATA: $data", Toast.LENGTH_SHORT).show()
            //set image captured to image view
            //photoimageView.setImageURI(image_uri)
        }
    }


}
