package com.leonel.qrroject.view

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.location.Location
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.firebase.ui.auth.AuthUI
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseUser
import com.leonel.qrroject.R
import com.leonel.qrroject.model.GPSservice
import kotlinx.android.synthetic.main.activity_home.*

class HomeActivity : AppCompatActivity(),HomeActivityView {
    lateinit var currentUser:FirebaseUser
    lateinit var gpsservice:GPSservice
    var lastPosition:Location? = null
    val PERMISSION_CODE = 1000
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        gpsservice = GPSservice(this,this)
        gpsservice.getUbicacion(bottom_navigation)
        currentUser = intent.getParcelableExtra("user")


    }

    override fun setupNavigation(navigationBar: BottomNavigationView) {

        navigationBar.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navCamera -> {
                    val fragment =
                        CameraFragment()
                    openFragment(fragment)
                    true
                }
                R.id.navHistorial -> {
                    val fragment =
                        HistorialFragment()
                    openFragment(fragment)
                    true
                }
                R.id.navLogOut -> {
                    AuthUI.getInstance().signOut(this)
                    val intento = Intent(this,LoginActivity::class.java)
                    startActivity(intento)
                    true
                }
                else -> false
            }
        }

        navigationBar.selectedItemId = R.id.navCamera


    }

    private fun openFragment(fragment: Fragment) {
        val bundle = Bundle()
        bundle.putString("user", currentUser.email)
        bundle.putString("lat",lastPosition?.latitude.toString())
        bundle.putString("lon",lastPosition?.longitude.toString())
        fragment.arguments = bundle
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.main_container, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }

    override fun getActivity(): Activity {
        return this
    }

    override fun getPermissions() {
        //permission was not enabled
        val permission = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        requestPermissions(permission, PERMISSION_CODE)
    }

    override fun setLocation(posicion: Location?) {
        lastPosition = posicion
    }
}
