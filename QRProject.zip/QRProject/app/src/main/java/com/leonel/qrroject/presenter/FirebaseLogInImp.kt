package com.leonel.qrroject.presenter

import android.app.Activity
import android.util.Log
import android.view.View
import androidx.core.app.ActivityCompat.startActivityForResult
import com.firebase.ui.auth.AuthUI
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.leonel.qrroject.view.LoginView

class FirebaseLogInImp(var view:LoginView, var actividad:Activity):FirebaseLogIn{
    val db = FirebaseFirestore.getInstance()
    override fun insertNewUser(user: String?) {
        db.collection("usuarios").document(user!!)
            .get()
            .addOnSuccessListener {
                    Log.d("Mensaje","Se encontro a $user")

            }
            .addOnFailureListener { exception ->
                Log.d("Mensaje","No se encontro a $user")
                Log.w("Mensaje", "Error getting documents: ", exception)
            }
        
    }

}