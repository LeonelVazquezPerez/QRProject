package com.leonel.qrroject.model

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.leonel.qrroject.R
import kotlinx.android.synthetic.main.item_qr.view.*

class HistorialAdapter(var lista: MutableList<Qr>, var context: Context) :
    RecyclerView.Adapter<HistorialAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        var vista = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_qr, parent, false)

        return MyViewHolder(vista,context)
    }

    override fun getItemCount(): Int {
        return lista.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        var qr = lista.get(position)
        holder.enlazarItem(qr)
    }

    class MyViewHolder(itemView: View, contexto: Context) : RecyclerView.ViewHolder(itemView) {


        var context = contexto

        fun enlazarItem(qr: Qr) {
            itemView.tvTexto.text = qr.text
            itemView.tvTimestamp.text = qr.createAt

            itemView.setOnClickListener(View.OnClickListener {


                //Toast.makeText(context,"Se oprimio2: $adapterPosition",Toast.LENGTH_SHORT).show()
                var  builder = AlertDialog.Builder(context);
                builder.setTitle(qr.text)
                    .setMessage("Escaneado el dia:\n ${qr.createAt} \n" +
                            "Coordenadas: \n lat ${qr.lat}, lon ${qr.long}")
                    .setNegativeButton("Regresar", null)
                builder.create().show()
            })

        }

    }



}