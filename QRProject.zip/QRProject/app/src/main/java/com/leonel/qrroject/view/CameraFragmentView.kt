package com.leonel.qrroject.view


interface CameraFragmentView {
    fun getPermissions()
    fun openCamera()
}