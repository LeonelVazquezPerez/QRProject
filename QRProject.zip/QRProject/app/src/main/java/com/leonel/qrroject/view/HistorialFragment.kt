package com.leonel.qrroject.view

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager

import com.leonel.qrroject.R
import com.leonel.qrroject.model.HistorialAdapter
import com.leonel.qrroject.model.Qr
import com.leonel.qrroject.presenter.HistorialPresenterImp
import kotlinx.android.synthetic.main.fragment_historial.*

/**
 * A simple [Fragment] subclass.
 */
class HistorialFragment : Fragment(),HistorialFragmentView {

    lateinit var vista:View
    lateinit var useremail:String
    lateinit var userlatitude:String
    lateinit var userlongitude:String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        useremail = arguments?.getString("user").toString()
        userlatitude = arguments?.getString("lat").toString()
        userlongitude = arguments?.getString("lon").toString()

        vista =  inflater.inflate(R.layout.fragment_historial, container, false)
        return vista
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var presentador = HistorialPresenterImp(this)
        presentador.getHistorial(useremail)
    }
    override fun setHistorial(lista: MutableList<Qr>) {
        Log.d("Mensaje","lista: ${lista.size}")
        var adaptader = HistorialAdapter(lista,vista.context)
        recyclerHistorial.layoutManager = LinearLayoutManager(vista.context)
        recyclerHistorial.adapter = adaptader
    }

}
