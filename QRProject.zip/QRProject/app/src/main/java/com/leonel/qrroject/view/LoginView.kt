package com.leonel.qrroject.view

interface LoginView {
    fun showData(name:String?)
}