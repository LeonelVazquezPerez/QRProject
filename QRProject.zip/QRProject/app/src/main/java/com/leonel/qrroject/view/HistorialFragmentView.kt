package com.leonel.qrroject.view

import com.leonel.qrroject.model.Qr

interface HistorialFragmentView {
    fun setHistorial(lista:MutableList<Qr>)
}