package com.leonel.qrroject.presenter

interface CameraPresenter {
    fun checkPermissions()
}