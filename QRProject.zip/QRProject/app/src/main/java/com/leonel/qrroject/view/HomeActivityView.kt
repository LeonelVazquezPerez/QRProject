package com.leonel.qrroject.view

import android.app.Activity
import android.location.Location
import com.google.android.material.bottomnavigation.BottomNavigationView

interface HomeActivityView {
    fun getActivity():Activity
    fun getPermissions()
    fun setLocation(posicion:Location?)
    fun setupNavigation(navigationBar: BottomNavigationView)
}