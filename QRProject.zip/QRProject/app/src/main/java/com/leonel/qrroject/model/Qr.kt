package com.leonel.qrroject.model

class Qr (
    var id:String,
    var lat:String,
    var long:String,
    var text:String,
    var createAt:String
)