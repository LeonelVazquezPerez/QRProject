package com.leonel.qrroject.view


import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.firebase.ui.auth.AuthUI
import com.google.firebase.auth.FirebaseAuth
import com.leonel.qrroject.R
import com.leonel.qrroject.presenter.FirebaseLogInImp
import kotlinx.android.synthetic.main.activity_main.*


class LoginActivity : AppCompatActivity(),FirebaseAuth.AuthStateListener,LoginView {

    private val URL_POLITICA: String = "http://google.com"
    val REQUEST_CODE = 200
    val PROVEEDOR_DESCONOCIDO = "desconocido"
    lateinit var mFirebaseAuth: FirebaseAuth
    lateinit var mFirebaseAuthListener: FirebaseAuth.AuthStateListener

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mFirebaseAuth = FirebaseAuth.getInstance()
        mFirebaseAuthListener = this

    }

    override fun showData(name: String?) {
        tvNombre.text = name
    }

   override fun onAuthStateChanged(f0: FirebaseAuth) {
        var user = f0.currentUser
        var proveedores = mutableListOf(
            AuthUI.IdpConfig.EmailBuilder().build()
        )

        //Ya inicio sesion?
        if(user != null){
            var proveedor =
                if(user.providerData != null){
                    user.providerData.get(1).providerId
                }else{
                    PROVEEDOR_DESCONOCIDO
                }
            
            val intento = Intent(this,HomeActivity::class.java)
            intento.putExtra("user",user)
            startActivity(intento)

        }else{
            startActivityForResult(AuthUI.getInstance()
                .createSignInIntentBuilder()
                .setIsSmartLockEnabled(false)
                .setAvailableProviders(proveedores)
                .setTosAndPrivacyPolicyUrls(URL_POLITICA,URL_POLITICA)
                .build(),REQUEST_CODE)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when(requestCode){
            REQUEST_CODE ->{
                if(resultCode == Activity.RESULT_OK){
                    Toast.makeText(applicationContext,"Bienvenido",Toast.LENGTH_LONG).show()
                }else{
                    Toast.makeText(applicationContext,"Algo salio mal",Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        mFirebaseAuth.addAuthStateListener(mFirebaseAuthListener)
    }

    override fun onPause() {
        super.onPause()
        if(mFirebaseAuthListener != null){
            mFirebaseAuth.removeAuthStateListener(mFirebaseAuthListener)
        }
    }

}
