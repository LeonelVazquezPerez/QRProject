package com.leonel.qrroject.presenter

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.leonel.qrroject.model.Qr
import com.leonel.qrroject.view.HistorialFragmentView

class FirestoreServiceImp {
    val db = FirebaseFirestore.getInstance()
    fun insertQR(qr:Qr){
        val query = db.collection("qrs")
            query.add(qr)
    }
    fun getQrsByUsers(user:String,vista:HistorialFragmentView):MutableList<Qr>{
        val lista: MutableList<Qr> = mutableListOf<Qr>()
        db.collection("qrs")
            .orderBy("createAt", Query.Direction.DESCENDING)
            .whereEqualTo("id", user)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {

                    lista.add(
                        Qr(
                            document.get("id").toString(),
                            document.get("lat").toString(),
                            document.get("long").toString(),
                            document.get("text").toString(),
                            document.get("createAt").toString()))
                    Log.d("Mensaje", "${document.id} => ${document.data}")

                }
                Log.d("Mensaje","ListaF: ${lista.size}")
                vista.setHistorial(lista)
            }
            .addOnFailureListener { exception ->
                Log.w("Mensaje", "Error getting documents: ", exception)
            }


        return lista
    }
}