package com.leonel.qrroject.presenter

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.leonel.qrroject.view.HistorialFragment
import com.leonel.qrroject.view.HistorialFragmentView

class HistorialPresenterImp(var vista: HistorialFragmentView):HistorialPresenter {
    val firestore = FirestoreServiceImp()
    override fun getHistorial(user: String) {
        firestore.getQrsByUsers(user,vista)
        //vista.setHistorial(lista)
    }

}