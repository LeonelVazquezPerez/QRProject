package com.leonel.qrroject.presenter

import android.view.View

interface FirebaseLogIn {

    fun insertNewUser(user:String?)
}