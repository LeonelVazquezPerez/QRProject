package com.leonel.qrroject.presenter

interface HistorialPresenter {
    fun getHistorial(user:String)
}