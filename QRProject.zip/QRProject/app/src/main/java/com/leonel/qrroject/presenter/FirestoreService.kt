package com.leonel.qrroject.presenter

interface FirestoreService {
}